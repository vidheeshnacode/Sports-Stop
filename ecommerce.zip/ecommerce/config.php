<?php
$currency = '₹';
$db_username = 'root';
$db_password = 'root';
$db_name = 'bolt';
$db_host = 'localhost';
$mysqli = new mysqli($db_host, $db_username, $db_password,$db_name);
?>
